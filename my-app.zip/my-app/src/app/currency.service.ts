import { computed, inject, Injectable, OnInit, Signal, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { toSignal } from '@angular/core/rxjs-interop';
import { Currency } from './currency-switcher/currency';
import { Observable } from 'rxjs/internal/Observable';
import { CakeItem } from './cake-item';

export type ExchangeRates = Record<Currency, number>;

export interface CurrencyInfo {
  currency: Currency;
  exchangeRate: number;
}

@Injectable({
  providedIn: 'root'
})
export class CurrencyService {

  private readonly currency = signal<Currency>("RON");
  private http = inject(HttpClient);

  private exchangeRates$ = this.getCurrencyRates();
  private exchangeRates = toSignal(this.exchangeRates$, {initialValue: {USD: 1, EUR: 1, RON: 1} });

  currencyInfo: Signal<CurrencyInfo> = computed(() => {
    return {currency: this.currency(), exchangeRate: this.exchangeRates()[this.currency()]};
  } )

  getCurrency(): Signal<CurrencyInfo> {
    return this.currencyInfo;
  }

  setCurrency(currency: Currency): void {
    this.currency.set(currency);
  }

  getCurrencyRates(): Observable<ExchangeRates> {
    return this.http.get<ExchangeRates>("assets/data/currency-rates.json");
  }

  getCakes(): Observable<CakeItem[]> {
    return this.http.get<CakeItem[]>("assets/data/cake-shop.json");
  }
}
