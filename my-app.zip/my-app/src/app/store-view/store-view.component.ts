import { AsyncPipe } from '@angular/common';
import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CurrencyService } from '../currency.service';
import { CakeItemComponent } from '../cake-item/cake-item.component';

@Component({
  selector: 'app-store-view',
  standalone: true,
  imports: [CakeItemComponent, AsyncPipe],
  templateUrl: './store-view.component.html'
})
export class StoreViewComponent {

  http = inject(HttpClient);
  service = inject(CurrencyService);
  
  currencyInfo = this.service.getCurrency();
  cakeSignal = this.service.getCakes();
}
