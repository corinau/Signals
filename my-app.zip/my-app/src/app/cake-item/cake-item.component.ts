import {Component, input} from '@angular/core';
import {CurrencyPipe} from '@angular/common';
import {CurrencyInfo} from '../currency.service';
import { CakeItem } from '../cake-item';

@Component({
  selector: 'app-cake-item',
  standalone: true,
  templateUrl: './cake-item.component.html',
  imports: [
    CurrencyPipe
  ],
  styleUrls: ['./cake-item.component.scss']
})
export class CakeItemComponent {
  // Signal-based component
  cake = input.required<CakeItem>();

  buttonText = input("");

  currencyInfo = input.required<CurrencyInfo>();

}
