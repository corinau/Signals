export type Currency = 'RON' | 'USD' | 'EUR';
