export interface CakeItem {
    id: string;
    picture: string;
    title: string;
    price: number;
    description: string;
  }
  