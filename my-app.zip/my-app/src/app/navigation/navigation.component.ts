import { Component } from '@angular/core';
import { CurrencySwitcherComponent } from '../currency-switcher/currency-switcher.component';

@Component({
  selector: 'app-navigation',
  standalone: true,
  imports: [CurrencySwitcherComponent],
  templateUrl: './navigation.component.html'
})
export class NavigationComponent {

}
